/* 
 * Travis Sands
 * 09/21/2024
 * CS-320 Testing and Automation QA
 */

package contactAppCS320;

public class Contact {
	public String contactID;
	public String firstName;
	public String lastName;
	public String phoneNumber;
	public String contactAddress;
	
	// Constructor
	public Contact(String contactID, String firstName, String lastName, String phoneNumber, String contactAddress) {
		if (contactID == null || contactID.length() > 10) {
			throw new IllegalArgumentException("Invalid contact ID");
		}
		
		if (firstName == null || firstName.length() > 10) {
			throw new IllegalArgumentException("Invalid first name");
		}
		
		if (lastName == null || lastName.length() > 10) {
			throw new IllegalArgumentException("Invalid last name");
		}
		
		if (phoneNumber == null || phoneNumber.length() != 10) {
			throw new IllegalArgumentException("Invalid phone number");
		}
		
		if (contactAddress == null || contactAddress.length() > 30) {
			throw new IllegalArgumentException("Invalid adress");
		}
		
		this.contactID = contactID;
		this.firstName = firstName;
		this.lastName = lastName;
		this.phoneNumber = phoneNumber;
		this.contactAddress = contactAddress;
		
	}
	
	// Getters and Setters
	public String getContactID() {
		return this.contactID;
	}
	
	public void setContactID(String newContactID) {
		if (newContactID == null || newContactID.length() > 10) {
			throw new IllegalArgumentException("Invalid contact ID");
		}
		
		contactID = newContactID;
	}
	
	public String getFirstName() {
		return this.firstName;
	}
	
	public void setFirstName(String newFirstName) {
		if (newFirstName == null || newFirstName.length() > 10) {
			throw new IllegalArgumentException("Invalid first name");
		}
		
		firstName = newFirstName;
	}
	
	public String getLastName() {
		return this.lastName;
	}
	
	public void setLastName(String newLastName) {
		if (newLastName == null || newLastName.length() > 10) {
			throw new IllegalArgumentException("Invalid last name");
		}
		
		lastName = newLastName;
	}
	
	public String getPhoneNumber() {
		return this.phoneNumber;
	}
	
	public void setPhoneNumber(String newPhoneNumber) {
		if (newPhoneNumber == null || newPhoneNumber.length() > 10) {
			throw new IllegalArgumentException("Invalid phone number");
		}
		
		phoneNumber = newPhoneNumber;
	}	
	
	public String getContactAddress() {
		return this.contactAddress;
	}
	
	public void setContactAddress(String newContactAddress) {
		if (newContactAddress == null || newContactAddress.length() > 10) {
			throw new IllegalArgumentException("Invalid contact address");
		}
		
		contactAddress = newContactAddress;
	}

	public Contact deleteContact(Contact contactList) {
		return null;
	}

}
