/*
 * Travis Sands
 * 9/21/24
 * CS-320 Testing and Automation QA
 */

package contactAppCS320;

import java.util.Scanner;

public class ContactService {

	@SuppressWarnings("unused")
	private static Contact contactList;
	static Scanner FirstName = new Scanner(System.in);
	static Scanner LastName = new Scanner(System.in);
	static Scanner PhoneNumber = new Scanner(System.in);
	static Scanner ContactAddress = new Scanner(System.in);
	
	public Contact addContact() {
		contactList = new Contact(null, null, null, null, null);
		return contactList;
	}
	public static Contact deleteContact() {
		contactList = contactList.deleteContact(contactList);
		return null;
	}
	public static void updateFirstName() {
		String firstName = FirstName.nextLine();
		contactList.setFirstName(firstName);
	}
	public static void updateLastName() {
		String lastName = LastName.nextLine();
		contactList.setLastName(lastName);
	}
	public static void updateNumber() {
		String phoneNumber = PhoneNumber.nextLine();
		contactList.setPhoneNumber(phoneNumber);
	}
	public static void updateAddress() {
		String contactAddress = ContactAddress.nextLine();
		contactList.setContactAddress(contactAddress);
	}
	
}
