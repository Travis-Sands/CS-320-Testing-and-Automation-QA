package contactAppCS320;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

@SuppressWarnings("unused")
class ContactServiceTest {

	@Test
	void addContact() {
		Contact contact = new Contact("0000000001", "Travis", "Sands", "5555555555", "123 Home Road");
		assertTrue(contact.getFirstName().equals("Travis"));
		assertTrue(contact.getContactID().equals("0000000001"));
	}
	
	@Test
	void testdeleteontact() {
		Contact contact = new Contact("0000000002", "Tom", "Brady", "5555555556", "123 Home Street");
		ContactService.deleteContact();
	};	
	
	@Test
	void testfirst() {
		Contact contact = new Contact("0000000002", "Tom", "Brady", "5555555556", "123 Home Street");
		ContactService.updateFirstName();
	};	
	
	@Test
	void testlast() {
		Contact contact = new Contact("0000000002", "Tom", "Brady", "5555555556", "123 Home Street");
		ContactService.updateLastName();
	};	
	
	@Test
	void testdigits() {
		Contact contact = new Contact("0000000002", "Tom", "Brady", "5555555556", "123 Home Street");
		ContactService.updateNumber();
	};	
	
	@Test
	void testaddress() {
		Contact contact = new Contact("0000000002", "Tom", "Brady", "5555555556", "123 Home Street");
		ContactService.updateAddress();
	};

}