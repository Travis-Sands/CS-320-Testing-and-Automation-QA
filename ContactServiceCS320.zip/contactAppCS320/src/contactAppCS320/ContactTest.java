package contactAppCS320;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;


public class ContactTest {
	
	@Test
	void testContactNullArguments() {
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			new Contact(null, null, null, null, null);
		});
	}
	
	@Test
	void testContact() {
		Contact contact = new Contact("0000000001", "Travis", "Sands", "5555555555", "123 Home Road");
		assertTrue(contact.getContactID().equals("0000000001"));
		assertTrue(contact.getFirstName().equals("Travis"));
		assertTrue(contact.getLastName().equals("Sands"));
		assertTrue(contact.getPhoneNumber().equals("5555555555"));
		assertTrue(contact.getContactAddress().equals("123 Home Road"));
	}
	
	@Test
	void testSetFirstName() {
		Contact contact = new Contact("0000000001", "Travis", "Sands", "5555555555", "123 Home Road");
		contact.setFirstName("Travis");
		assertTrue(contact.getFirstName().equals("Travis"));
	}
	
	@Test
	void testSetLastName() {
		Contact contact = new Contact("0000000001", "Travis", "Sands", "5555555555", "123 Home Road");
		contact.setLastName("Sands");
		assertTrue(contact.getLastName().equals("Sands"));
	}
	
	@Test
	void testSetPhoneNumber() {
		Contact contact = new Contact("0000000001", "Travis", "Sands", "5555555555", "123 Home Road");
		contact.setPhoneNumber("5555555555");
		assertTrue(contact.getPhoneNumber().equals("5555555555"));
	}
	
	@Test
	void testSetContactAddress() {
		Contact contact = new Contact("0000000001", "Travis", "Sands", "5555555555", "123 Home Road");
		contact.setContactAddress("123 Home Road");
		assertTrue(contact.getContactAddress().equals("123 Home Road"));
	}
	
	@Test
	void testNullSetAttributes() {
		Contact contact = new Contact("0000000001", "Travis", "Sands", "5555555555", "123 Home Road");
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			contact.setContactID(null);
		});
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			contact.setFirstName(null);
		});
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			contact.setLastName(null);
		});
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			contact.setPhoneNumber(null);
		});
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			contact.setContactAddress(null);
		});
	}
	
	@Test
	void testlengthSetAttributes() {
		Contact contact = new Contact("0000000001", "Travis", "Sands", "5555555555", "123 Home Road");
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			contact.setFirstName("00000000010");
		});
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			contact.setFirstName("Mister Travis");
		});
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			contact.setLastName("Mister Sands ");
		});
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			contact.setPhoneNumber("5555555");
		});
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			contact.setContactAddress("123 This address is way to long for this requirement");
		});
	}

}